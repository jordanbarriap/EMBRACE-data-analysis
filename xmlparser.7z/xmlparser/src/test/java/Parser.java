

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.opencsv.CSVWriter;



public class Parser {

	public static Node nodenl;
	public static String User_Action_ID = null;
	public static String Selection = null;
	public static String Action = null;
	public static String Verification = null;
	public static String Time = null;

	public static void xmlReading(String xmlFile_path) throws ParserConfigurationException, SAXException, IOException {
		// Writing into csv file
		File file = new File("Properties.csv");
		FileWriter outputfile = new FileWriter(file);
		List<String[]> data = new ArrayList<String[]>();
		CSVWriter writer = new CSVWriter(outputfile);
		
		data.add(new String[] { "User_Action_ID", "Selection", "Action", "Verification", "Time" });
		//Reading gmxml file
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new File(xmlFile_path));
		document.getDocumentElement().normalize();
		Element root = document.getDocumentElement();
		NodeList screensList = document.getElementsByTagName("Study");
		NodeList list =screensList.item(0).getChildNodes();
		for(int i=0;i<list.getLength();i++) {
			NodeList childlist=list.item(i).getChildNodes();
			String node=list.item(i).getNodeName();
			if(node.equalsIgnoreCase("User_Action")||node.equalsIgnoreCase("System_Action")) {
				
				for(int j=0;j<childlist.getLength();j++) {
					String cnode=childlist.item(j).getNodeName();
					if(cnode.equalsIgnoreCase("User_Action_ID")) {
						User_Action_ID=childlist.item(j).getTextContent();
					}else if(cnode.equalsIgnoreCase("Selection")) {
						Selection=childlist.item(j).getTextContent();
					}else if(cnode.equalsIgnoreCase("Action")) {
						Action=childlist.item(j).getTextContent();
					}else if(cnode.equalsIgnoreCase("Input")) {
						NodeList nl=childlist.item(j).getChildNodes();
						List input = new ArrayList();
						for(int n=0;n<nl.getLength();n++) {
							input.add(nl.item(n).getNodeName());
						}
						if(input.contains("Verification")) 
							Verification=nl.item(1).getTextContent();
							
							Verification=null;
					} else if(cnode.equalsIgnoreCase("Context")) {
						NodeList nl=childlist.item(j).getChildNodes();
						for(int n=0;n<nl.getLength();n++) {
							if(nl.item(n).getNodeName().equalsIgnoreCase("Study_Context")) {
								NodeList n1=nl.item(n).getChildNodes();
								for(int m=0;m<n1.getLength();m++) {
									if(n1.item(m).getNodeName().equalsIgnoreCase("Timestamp")) {
										NodeList n2=n1.item(m).getChildNodes();
										for(int l=0;l<n2.getLength();l++) {
											if(n2.item(l).getNodeName().equalsIgnoreCase("Time")) {
												Time=n2.item(l).getTextContent();
											}
										}
									
									}
								}
							}
						}
						
					}
					
					
				}
			}
			
			data.add(new String[] { User_Action_ID, Selection, Action, Verification, Time});
		}
		

		writer.writeAll(data);
		writer.close();
	}

	public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {
		//path of final GMXML file
		String xmlFile_path =System.getProperty("user.dir") + "/test1.xml"; ;
		//System.getProperty("user.dir") + "/test1.xml";

		xmlReading(xmlFile_path);

	}

}
