import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.opencsv.CSVWriter;

public class Test2 {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

		
		String path=System.getProperty("user.dir") +"/project/p1";

		File fl= new File(path);

		String []files=fl.list();
		
		for(String f:files){
			File temp= new File(path+"\\"+ f);
			if(temp.isFile()){
				String flnm= f.substring(0,f.lastIndexOf("."));
				File file = new File(path+"\\"+flnm+".csv");
				FileWriter outputfile = new FileWriter(file);
				List<String[]> data = new ArrayList<String[]>();
				CSVWriter writer = new CSVWriter(outputfile);
				
				Node nodenl=null;
				String Selection = null;String Action = null;String Concrete = null;String Abstract = null;
				String Relational = null;String ReaderInProgress = null;String LanguageInProgress = null;

				data.add(new String[] {"Selection", "Action", "Concrete", "Abstract", "Relational", "ReaderInProgress", "LanguageInProgress" });
				//Reading gmxml file
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document document = builder.parse(temp);
				document.getDocumentElement().normalize();
				Element root = document.getDocumentElement();
				NodeList screensList = document.getElementsByTagName("Study");
				NodeList list =screensList.item(0).getChildNodes();
				for(int i=0;i<list.getLength();i++) {
					NodeList childlist=list.item(i).getChildNodes();
					String node=list.item(i).getNodeName();
					if(node.equalsIgnoreCase("User_Action")||node.equalsIgnoreCase("System_Action")) {
						
						for(int j=0;j<childlist.getLength();j++) {
							String cnode=childlist.item(j).getNodeName();
							if(cnode.equalsIgnoreCase("Selection")) {
								Selection=childlist.item(j).getTextContent();
							}else if(cnode.equalsIgnoreCase("Action")) {
								Action=childlist.item(j).getTextContent();
							}else if(cnode.equalsIgnoreCase("Input")) {
								NodeList nl=childlist.item(j).getChildNodes();
								for(int n=0;n<nl.getLength();n++) {
									String scnode=nl.item(n).getNodeName();
									if(scnode.equalsIgnoreCase("Concrete")) {
										Concrete=nl.item(n).getTextContent();
									}else if(scnode.equalsIgnoreCase("Abstract")) {
										Abstract=nl.item(n).getTextContent();
									}else if(scnode.equalsIgnoreCase("Relational")) {
										Relational=nl.item(n).getTextContent();
									}else if(scnode.equalsIgnoreCase("ReaderInProgress")) {
										ReaderInProgress=nl.item(n).getTextContent();
									}else if(scnode.equalsIgnoreCase("LanguageInProgress")) {
										LanguageInProgress=nl.item(n).getTextContent();
									}
									
								}
								
							} 
							
							
						}
					}
					
					data.add(new String[] {Selection, Action, Concrete, Abstract, Relational, ReaderInProgress, LanguageInProgress});
				}
				

				writer.writeAll(data);
				writer.close();

			}

		} 
	}
}
