import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.opencsv.CSVWriter;

public class Test1 {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
// Change the folder name like user2 or user3 based on requirement
		
		String path=System.getProperty("user.dir") +"/project/user8";

		File fl= new File(path);

		String []files=fl.list();
		
		for(String f:files){
			File temp= new File(path+"\\"+ f);
			if(temp.isFile()){
				String flnm= f.substring(0,f.lastIndexOf("."));
				File file = new File(path+"\\"+flnm+".csv");
				FileWriter outputfile = new FileWriter(file);
				List<String[]> data = new ArrayList<String[]>();
				CSVWriter writer = new CSVWriter(outputfile);
				String Book_Title = null,Chapter_Number = null,Chapter_Title = null;
				data.add(new String[] { "Book_Title", "Chapter_Number", "Chapter_Title"});
				//Reading gmxml file
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document document = builder.parse(temp);
				document.getDocumentElement().normalize();
				Element root = document.getDocumentElement();
				NodeList ManipulationContext = document.getElementsByTagName("Manipulation_Context");
				for(int n=0;n<ManipulationContext.getLength();n++) {
					NodeList nodes=ManipulationContext.item(n).getChildNodes();
					for(int i=0;i<nodes.getLength();i++) {
						String node=nodes.item(i).getNodeName();
						if(node.equals("Book_Title")) {
							 Book_Title=nodes.item(i).getTextContent();
						}
						if(node.equals("Chapter_Number")) {
							 Chapter_Number=nodes.item(i).getTextContent();
						}
						if(node.equals("Chapter_Title")) {
							 Chapter_Title=nodes.item(i).getTextContent();
						}
						
					}
					data.add(new String[] { Book_Title, Chapter_Number, Chapter_Title});
				}

					
					
				
				

				writer.writeAll(data);
				writer.close();

			}

		} 
	}
}
